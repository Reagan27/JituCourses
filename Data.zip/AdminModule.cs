﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

public class AdminModule
{
    private List<Course> courses = new List<Course>();
    private List<AnalyticsEntry> analyticsData = new List<AnalyticsEntry>();

    

    public void AddCourse(Course course)
    {
        courses.Add(course);
        SaveCoursesToFile();
    }

    public void DeleteCourse(string courseName)
    {
        courses.RemoveAll(course => course.CourseName == courseName);
        SaveCoursesToFile();
    }

    public List<Course> ViewAllCourses()
    {
        return courses;
    }

    public List<AnalyticsEntry> ViewAnalytics()
    {
        return analyticsData;
    }

    private void SaveCoursesToFile()
    {
        using (StreamWriter writer = new StreamWriter("Data/courses.txt"))
        {
            foreach (Course course in courses)
            {
                writer.WriteLine($"{course.CourseName},{course.Price}");
            }
        }
    }
}
