﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

public class Course
{
    public string CourseName { get; set; }
    public decimal Price { get; set; }
}

public class CoursesModule
{
    private List<Course> availableCourses = new List<Course>();

    public void AddAvailableCourse(Course course)
    {
        availableCourses.Add(course);
        SaveAvailableCoursesToFile();
    }

    public List<Course> GetAvailableCourses()
    {
        return availableCourses;
    }

    private void SaveAvailableCoursesToFile()
    {
        using (StreamWriter writer = new StreamWriter("Data/availableCourses.txt"))
        {
            foreach (Course course in availableCourses)
            {
                writer.WriteLine($"{course.CourseName},{course.Price}");
            }
        }
    }
}
