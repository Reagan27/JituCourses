﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

public class User
{
    public string Username { get; set; }
    public string Password { get; set; }
    public UserRole Role { get; set; }
}

public enum UserRole
{
    User,
    Admin
}

public class UsersModule
{
    private List<User> users = new List<User>();

    public void AddUser(User user)
    {
        users.Add(user);
        SaveUsersToFile();
    }

    public User AuthenticateUser(string username, string password)
    {
        return users.FirstOrDefault(user => user.Username == username && user.Password == password);
    }

    private void SaveUsersToFile()
    {
        using (StreamWriter writer = new StreamWriter("Data/users.txt"))
        {
            foreach (User user in users)
            {
                writer.WriteLine($"{user.Username},{user.Password},{user.Role}");
            }
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        UsersModule usersModule = new UsersModule();

        
        User newUser = new User { Username = "Reagan", Password = "password", Role = UserRole.User };
        usersModule.AddUser(newUser);

        // Authenticate user
        User authenticatedUser = usersModule.AuthenticateUser("Reagan", "password");
        if (authenticatedUser != null)
        {
            Console.WriteLine($"Authenticated user: {authenticatedUser.Username}, Role: {authenticatedUser.Role}");
        }
        else
        {
            Console.WriteLine(" failed.");
        }
    }
}
