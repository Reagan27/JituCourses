﻿using System;
using System.Collections.Generic;
using System.IO;

public class PurchaseModule
{
    private List<AnalyticsEntry> analyticsData;

    public PurchaseModule(List<AnalyticsEntry> analyticsData)
    {
        this.analyticsData = analyticsData;
    }

    public void PurchaseCourse(User user, Course course)
    {
        // Simulate STK push (placeholder simulation)
        Console.WriteLine($"Simulating STK push for user {user.Username} to purchase course {course.CourseName}");

        // Save purchase data to analytics
        AnalyticsEntry entry = new AnalyticsEntry
        {
            Username = user.Username,
            CoursePurchased = course.CourseName,
            PurchaseDate = DateTime.Now
        };
        analyticsData.Add(entry);
        SaveAnalyticsToFile();
    }

    private void SaveAnalyticsToFile()
    {
        using (StreamWriter writer = new StreamWriter("Data/analytics.txt"))
        {
            foreach (AnalyticsEntry entry in analyticsData)
            {
                writer.WriteLine($"{entry.Username},{entry.CoursePurchased},{entry.PurchaseDate}");
            }
        }
    }

    
}
