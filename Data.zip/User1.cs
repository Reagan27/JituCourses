﻿using System;
using System.Collections.Generic;

namespace Assignment
{
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public UserRole Role { get; set; }
    }

    public enum UserRole
    {
        User,
        Admin
    }

    public class UsersModule
    {
        private List<User> users = new List<User>();

        public void AddUser(User user)
        {
            users.Add(user);
            
        }

        public User AuthenticateUser(string username, string password)
        {
            // Authenticate 
        }

        
    }

    public class AdminModule
    {
        private List<Course> courses = new List<Course>();
        private List<AnalyticsEntry> analyticsData = new List<AnalyticsEntry>();

        public void AddCourse(Course course)
        {
            courses.Add(course);
            // Save courses to courses.txt
        }

        public void DeleteCourse(string courseName)
        {
            courses.RemoveAll(course => course.CourseName == courseName);
            // Update courses.text
        }

        public List<Course> ViewAllCourses()
        {
            return courses;
        }

        public List<AnalyticsEntry> ViewAnalytics()
        {
            return analyticsData;
        }

        
    }

    public class Course
    {
        public string CourseName { get; set; }
        public decimal Price { get; set; }
    }

    public class AnalyticsEntry
    {
        public string Username { get; set; }
        public string CoursePurchased { get; set; }
        public DateTime PurchaseDate { get; set; }
    }

    public class CoursesModule
    {
        private List<Course> availableCourses = new List<Course>();

        public void AddAvailableCourse(Course course)
        {
            availableCourses.Add(course);
            
        }

        public List<Course> GetAvailableCourses()
        {
            return availableCourses;
        }

        
    }

    class Program
    {
        static void Main(string[] args)
        {
            //program Logic
        }
    }
}
