﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    public class UsersModule
    {
        private List<User> users = new List<User>();

        public void AddUser(User user)
        {
            users.Add(user);
            // Save users 
        }

        public User AuthenticateUser(string username, string password)
        {
            return users.FirstOrDefault(user => user.Username == username && user.Password == password);
        }

        
    }
}
